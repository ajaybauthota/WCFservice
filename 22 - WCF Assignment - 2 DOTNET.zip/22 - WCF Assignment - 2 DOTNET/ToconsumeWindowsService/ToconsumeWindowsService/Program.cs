﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToconsumeWindowsService
{
    class Program
    {
        static void Main(string[] args)
        {
            MyWCFService.Service1Client MyServiceClient = new MyWCFService.Service1Client();
            Console.WriteLine("celciustofarenheit: "+ MyServiceClient.celciustofarenheit(37));
            Console.WriteLine("farenheittocelcius: "+MyServiceClient.farenheittocelcius(100));
            Console.ReadLine();
        }
    }
}
