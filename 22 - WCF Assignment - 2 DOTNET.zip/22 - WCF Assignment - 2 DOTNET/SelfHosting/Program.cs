﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Description;
using _22___WCF_Assignment___2_DOTNET;

namespace SelfHosting
{
    class Program
    {
        static void Main(string[] args)
        {
            Uri httpUrl = new Uri("http://localhost:61718/Service1.svc");
            //Create ServiceHost
            ServiceHost HttpHost = new ServiceHost(typeof(_22___WCF_Assignment___2_DOTNET.Service1), httpUrl);
            //Add a service endpoint
            HttpHost.AddServiceEndpoint(typeof(_22___WCF_Assignment___2_DOTNET.IService1), new BasicHttpBinding(), "");
            //Enable metadata exchange
            ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
            smb.HttpGetEnabled = true;
            HttpHost.Description.Behaviors.Add(smb);
            //Start the Service
            HttpHost.Open();
            Console.WriteLine("HTTP Service is host at " + DateTime.Now.ToString());
            Console.WriteLine("HTTP Host is running... Press <Enter> key to stop");
            Console.ReadLine();
        }
    }
}
