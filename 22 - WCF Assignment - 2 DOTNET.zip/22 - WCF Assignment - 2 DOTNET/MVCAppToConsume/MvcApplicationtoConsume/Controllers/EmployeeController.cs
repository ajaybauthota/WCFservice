﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplicationtoConsume.WCFService;
using MvcApplicationtoConsume.Models;

namespace MvcApplicationtoConsume.Controllers
{
    public class EmployeeController : Controller
    {

        WCFService.Service1Client WCFService1Client = new WCFService.Service1Client();
        [HttpGet]
        public ActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddEmployee(Employee objEmployee)
        {
            string Result = WCFService1Client.AddEmployee(objEmployee);
            ViewData["result"] = Result;
            ModelState.Clear();
            return View();
        }


        [HttpGet]
        public ActionResult UpdateEmployee(string ID)
        {
            return View(WCFService1Client.RetreiveEmployeeByID(ID));
        }
        [HttpPost]
        public ActionResult UpdateEmployee(Employee objEmployee)
        {
            if (ModelState.IsValid) //checking model is valid or not
            {   
                string result = WCFService1Client.UpdateEmployee(objEmployee);
                ViewData["result"] = result;
                ModelState.Clear(); //clearing model
                return View();
            }
            else
            {
                ModelState.AddModelError("", "Error in saving data");
                return View();
            }
        }

        [HttpGet]
        public ActionResult DeleteEmployee(string ID)
        {
            return View(WCFService1Client.RetreiveEmployeeByID(ID));
        }
        [HttpPost]
        public ActionResult DeleteEmployee(Employee objEmployee)
        {
            string result = WCFService1Client.DeleteEmployee(objEmployee.emp_no.ToString());
            ViewData["result"] = result;
            ModelState.Clear(); //clearing model
            return View();
        }



        public ActionResult RetreiveEmployeeByID(string ID)
        {
            Employee objEmployee = WCFService1Client.RetreiveEmployeeByID(ID);
            return View(objEmployee);

        }
        public ActionResult RetreiveEmployees()
        {
            List<Employee> listEmployee = new List<Employee>();
            listEmployee = WCFService1Client.RetreiveEmployees().ToList();
            return View(listEmployee.AsEnumerable());
        }
    }
}
